
class load:

    def __init__(self,file_name = None):
        self.file_name = file_name

    def transform(self):
        print("YES",self.file_name)


